-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 24-06-2023 a las 20:42:32
-- Versión del servidor: 10.4.28-MariaDB
-- Versión de PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `veterinaria`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `carrito`
--

CREATE TABLE `carrito` (
  `id_carrito` int(32) NOT NULL,
  `nombre` varchar(120) NOT NULL,
  `precio` varchar(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `eventoscalendar`
--

CREATE TABLE `eventoscalendar` (
  `id` int(11) NOT NULL,
  `evento` varchar(250) DEFAULT NULL,
  `color_evento` varchar(20) DEFAULT NULL,
  `fecha_inicio` varchar(20) DEFAULT NULL,
  `fecha_fin` varchar(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Volcado de datos para la tabla `eventoscalendar`
--

INSERT INTO `eventoscalendar` (`id`, `evento`, `color_evento`, `fecha_inicio`, `fecha_fin`) VALUES
(51, 'Mi Primera Prueba', 'teal', '2021-07-07', '2021-07-08'),
(52, 'Mi Segunda Prueba', 'amber', '2021-07-17', '2021-07-18'),
(53, 'Mi Tercera Prueba', 'orange', '2021-07-03', '2021-07-04'),
(55, 'Borrar Base De Datos', '#FF5722', '2023-06-09', '2023-06-10'),
(57, 'Entrega Software', '#FF5722', '2023-06-24', '2023-06-25');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `producto`
--

CREATE TABLE `producto` (
  `id_producto` int(32) NOT NULL,
  `nombre` varchar(120) NOT NULL,
  `cantidad` varchar(120) NOT NULL,
  `precio` varchar(120) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `producto`
--

INSERT INTO `producto` (`id_producto`, `nombre`, `cantidad`, `precio`) VALUES
(1, 'Royal Canin Croquetas para gatos adultos', '21', '350'),
(2, 'Hill Prescription Diet Canine c/d', '15', '100'),
(3, 'Bayer Advantage antipulgas para perros', '30', '280'),
(4, 'Purina Pro Plan Veterinary Diets EN', '50', '420'),
(5, 'Frontline Spot-On para gatos', '10', '180'),
(6, 'Virbac Pasta dental para perros y gatos', '44', '120'),
(7, 'Nutro Grain Free Puppy', '5', '550'),
(8, 'Kong Juguete para masticar', '50', '150'),
(10, 'Seresto Collar antipulgas y garrapatas para perros', '12', '650'),
(11, 'ProPlan Alimento húmedo para gatos adultos', '68', '45'),
(12, 'Hill Science Diet Canine Adulto', '32', '380'),
(13, 'Bayer Seresto Gatos Collar Antipulgas', '6', '570'),
(14, 'Royal Canin Urinary Care para gatos', '15', '420'),
(15, 'Virbac Shampoo para perros y gatos', '22', '150'),
(16, 'Pedigree Dentastix para perros', '40', '120'),
(17, 'Nutro Grain Free Senior', '4', '520'),
(18, 'Kong Pelota de goma resistente', '13', '160'),
(19, 'Feliway Spray calmante para gatos', '33', '280'),
(20, 'Seresto Collar antipulgas y garrapatas para gatos', '20', '610'),
(21, 'Purina ONE Gatos Esterilizados', '12', '360'),
(22, 'Hill Prescription Diet Feline k/d', '5', '430'),
(23, 'Bayer Drontal Plus para perros', '9', '240'),
(24, 'Frontline Spot-On para perros', '15', '200'),
(25, 'Virbac Eliminador de manchas y olores para mascotas', '22', '180'),
(26, 'Nutro Grain Free Puppy Large Breed', '3', '590'),
(27, 'Kong Dispensador de premios para perros', '21', '190'),
(28, 'Feliway Difusor recambio para gatos', '26', '280'),
(29, 'Royal Canin Alimento seco para perros adultos', '33', '320'),
(30, 'Hill Science Diet Canine Cachorro', '5', '410'),
(31, 'Bayer Advocate antiparasitario para perros', '18', '350'),
(32, 'Purina ONE Perros Adultos Razas Pequeñas', '28', '280'),
(33, 'Frontline Spray antipulgas y garrapatas', '14', '250'),
(34, 'Pedigree Perros Adultos', '3', '200');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `servicio`
--

CREATE TABLE `servicio` (
  `id_servicio` int(32) NOT NULL,
  `nombre` varchar(120) NOT NULL,
  `descripcion` text NOT NULL,
  `precio` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `servicio`
--

INSERT INTO `servicio` (`id_servicio`, `nombre`, `descripcion`, `precio`) VALUES
(1, 'Corte de pelo', 'Se realiza el corte de pelo del animal en cuestion ', '200'),
(2, 'Consulta veterinaria', 'Examen y diagnóstico de la salud general de la mascota.', '50'),
(3, 'Vacunación', 'Administración de vacunas para prevenir enfermedades comunes en mascotas.', '30'),
(4, 'Desparasitación', 'Tratamiento para eliminar parásitos internos y externos.', '40'),
(5, 'Cirugía', 'Realización de procedimientos quirúrgicos, como esterilización, castración u operaciones específicas.', '1000'),
(6, 'Radiología', 'Realización de radiografías para diagnosticar y evaluar problemas de salud.', '500'),
(7, 'Odontología veterinaria', 'Limpieza dental, extracción de dientes y tratamiento de enfermedades dentales.', '200'),
(8, 'Control de peso y nutrición', 'Asesoramiento sobre la alimentación adecuada y programas de control de peso para mascotas con sobrepeso o bajo peso.', '100'),
(9, 'Hospedaje y cuidado de mascotas', 'Servicios de alojamiento temporal y cuidado para mascotas cuando los propietarios están ausentes.', '300');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `id_usuario` int(11) NOT NULL,
  `nombre` varchar(120) NOT NULL,
  `correo` varchar(120) NOT NULL,
  `password` varchar(32) NOT NULL,
  `especialidad` varchar(60) NOT NULL,
  `telefono` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id_usuario`, `nombre`, `correo`, `password`, `especialidad`, `telefono`) VALUES
(1, 'Eduardo', 'ecalderon@solsoft.com.mx', '4d186321c1a7f0f354b297e8914ab240', 'Administrador', 'S/N'),
(2, 'Brandom Desiato\r\n', 'lomas9003@gmail.com', 'Sala15', 'Administrador', '5520022840');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `carrito`
--
ALTER TABLE `carrito`
  ADD PRIMARY KEY (`id_carrito`);

--
-- Indices de la tabla `eventoscalendar`
--
ALTER TABLE `eventoscalendar`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `producto`
--
ALTER TABLE `producto`
  ADD UNIQUE KEY `id` (`id_producto`);

--
-- Indices de la tabla `servicio`
--
ALTER TABLE `servicio`
  ADD UNIQUE KEY `id` (`id_servicio`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id_usuario`),
  ADD UNIQUE KEY `usuario_correo_idx` (`correo`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `carrito`
--
ALTER TABLE `carrito`
  MODIFY `id_carrito` int(32) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `eventoscalendar`
--
ALTER TABLE `eventoscalendar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- AUTO_INCREMENT de la tabla `producto`
--
ALTER TABLE `producto`
  MODIFY `id_producto` int(32) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT de la tabla `servicio`
--
ALTER TABLE `servicio`
  MODIFY `id_servicio` int(32) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
