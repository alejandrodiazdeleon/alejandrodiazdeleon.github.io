<?php
require "conexion.php";

$conexion = abrirConexion();

// Obtener la lista de productos desde la base de datos
$consulta = "SELECT * FROM producto";
$resultado = mysqli_query($conexion, $consulta);
$productos = mysqli_fetch_all($resultado, MYSQLI_ASSOC);

// Comprobar si se ha enviado un formulario de agregar al carrito
if (isset($_POST['agregar'])) {
    $productoId = $_POST['producto'];

    // Buscar el producto seleccionado en la lista de productos
    foreach ($productos as $producto) {
        if ($producto['id_producto'] == $productoId) {
            // Insertar el producto en la tabla carrito
            $insertar = "INSERT INTO carrito (nombre, precio) VALUES ('" . $producto['nombre'] . "', " . $producto['precio'] . ")";
            mysqli_query($conexion, $insertar);
            break;
        }
    }
}

// Comprobar si se ha confirmado la compra
if (isset($_POST['finalizar'])) {
    // Realizar las operaciones necesarias para finalizar la compra
    // ...

    // Vaciar la tabla carrito
    $vaciarCarrito = "TRUNCATE TABLE carrito";
    mysqli_query($conexion, $vaciarCarrito);

    // Mostrar mensaje de compra exitosa
    $mensaje = "Compra realizada con éxito";
}

// Obtener los productos en el carrito
$consultaCarrito = "SELECT nombre, precio FROM carrito";
$resultadoCarrito = mysqli_query($conexion, $consultaCarrito);
$productosCarrito = mysqli_fetch_all($resultadoCarrito, MYSQLI_ASSOC);

// Calcular el total de la compra
$totalCompra = 0;
foreach ($productosCarrito as $producto) {
    $totalCompra += $producto['precio'];
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Venta de Productos</title>
    <style>
        body {
            background-color: #f2f2f2;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }

        h1 {
            text-align: center;
            color: #333333;
            margin-top: 0;
        }

        .form-container {
            text-align: center;
            margin-bottom: 20px;
        }

        .form-container select {
            padding: 8px;
        }

        .form-container button {
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
            font-size: 16px;
        }

        .carrito-container {
            background-color: #ffffff;
            border: 1px solid #dddddd;
            padding: 20px;
            margin-bottom: 20px;
        }

        .carrito-container h2 {
            margin-top: 0;
            color: #333333;
        }

        .carrito-container ul {
            list-style-type: none;
            padding: 0;
        }

        .carrito-container li {
            margin-bottom: 10px;
        }

        .resumen-container {
            text-align: center;
            margin-bottom: 20px;
        }

        .resumen-container p {
            font-size: 18px;
        }

        .mensaje-container {
            background-color: #4CAF50;
            color: white;
            padding: 10px;
            text-align: center;
            margin-bottom: 20px;
        }

        .finalizar-container {
            text-align: center;
            margin-bottom: 20px;
        }

        .finalizar-container button {
            padding: 10px 20px;
            background-color: #ff0000;
            color: white;
            border: none;
            cursor: pointer;
            font-size: 16px;
        }
    </style>
</head>
<body>
    <?php include 'template/cabezera.html'; ?>

    <div class="container">
        <h1 style="color: black;">Venta de Productos</h1>

        <div class="form-container">
            <form method="post">
                <label for="producto">Seleccione un producto:</label>
                <select name="producto" id="producto">
                    <?php foreach ($productos as $producto): ?>
                        <option value="<?php echo $producto['id_producto']; ?>"><?php echo $producto['nombre']; ?></option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" name="agregar">Agregar al carrito</button>
            </form>
        </div>

        <?php if (!empty($productosCarrito)): ?>
            <div class="carrito-container">
                <h2>Venta de Productos</h2>
                <ul>
                    <?php foreach ($productosCarrito as $producto): ?>
                        <li><?php echo $producto['nombre']; ?> - Precio: <?php echo $producto['precio']; ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php if (isset($mensaje)): ?>
            <div class="mensaje-container">
                <?php echo $mensaje; ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($productosCarrito)): ?>
            <div class="resumen-container">
                <h2>Resumen de Compra</h2>
                <p>Total: <?php echo $totalCompra; ?></p>
            </div>
        <?php endif; ?>

        <div class="finalizar-container">
            <form method="post">
                <button type="submit" name="finalizar">Finalizar Compra</button>
            </form>
        </div>
    </div>

    <?php include 'template/pie.html'; ?>
</body>
</html>
