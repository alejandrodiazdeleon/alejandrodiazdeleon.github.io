<?php include 'template/cabezera.html'; ?>
<?php
require "conexion.php";

$conexion = abrirConexion();

// Función para eliminar un producto de la base de datos
function eliminarServicio($id_producto) {
    global $conexion;

    $id_producto = mysqli_real_escape_string($conexion, $id_producto);

    $query = "DELETE FROM producto WHERE id_producto = '$id_producto'";
    mysqli_query($conexion, $query);
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Verificar si se hizo clic en el botón "Borrar"
    if (isset($_POST["borrar"])) {
        $id_producto = $_POST["id_producto"];

        eliminarServicio($id_producto);
    }
}
// Cerrar la conexión
mysqli_close($conexion);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Productos</title>
    <link rel="stylesheet" href="./css/styleproductos.css">
</head>
<body>
    <h1><center><font color="white">Borrar Producto</font></center></h1>
    <form method="POST" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
    <br><br>
        <input type="text" name="id_producto" id="id_producto" placeholder="ID del producto" required>
        <br><br>&nbsp;&nbsp;&nbsp;&nbsp;
        <button type="submit" name="borrar">Borrar</button>
    </form>
</body>
</html>

<?php include 'template/pie.html'; ?>