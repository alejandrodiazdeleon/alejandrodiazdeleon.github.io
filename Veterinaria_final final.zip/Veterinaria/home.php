<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Veterinaria "El Tigre"</title>
    <link rel="stylesheet" href="./css/stylehome.css">
    <style>
        body {
            background-image: url('img/fondo.png');
        }

        .button-container {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            height: 100vh;
        }

        .button-container .button {
            display: block;
            width: 200px;
            height: 80px;
            margin-bottom: 20px;
            background-color: #ffbe00;
            color: #fff;
            text-align: center;
            line-height: 80px;
            text-decoration: none;
            font-weight: bold;
            font-size: 18px;
            border-radius: 5px;
        }

        .button-container .button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <header>
        <nav>
            <h1><img src="img/logo.png" width="90" alt="logo.png"></h1>
            <ul>
            <li><a href="home.php">HOME</a></li>
            <li><a href="productos.php">Productos</a></li>
            <li><a href="ventadeproductos.php">Venta de Productos</a></li>
            <li><a href="servicios.php">Servicios</a></li>
            <li><a href="ventaServicios.php">Venta de Servicios</a></li>
            <li><a href="agenda/index.php">Agenda</a></li>
            <li><a href="index.html">Cerrar sesion</a></li>
            </ul>
        </nav>
    </header>

    <div class="button-container">
        <a href="productos.php" class="button">Productos</a>
        <a href="servicios.php" class="button">Servicios</a>
        <a href="agenda/index.php" class="button">Agenda</a>
    </div>
</body>
</html>
