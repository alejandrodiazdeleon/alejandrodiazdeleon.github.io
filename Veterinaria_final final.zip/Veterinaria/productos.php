<?php include 'template/cabezera.html'; ?>
<?php
require "conexion.php";

$conexion = abrirConexion();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Productos</title>
    <link rel="stylesheet" href="./css/styleproductos.css">
</head>
<body>
    <h1><center><font color="white">Productos</font></center></h1>
    <form method="get" action="">
        <nav>
            <input type="text" name="busqueda" placeholder="Nombre del producto">
            &nbsp;&nbsp;&nbsp;&nbsp;
            <input type="text" name="busquedaId" placeholder="ID del producto">
            &nbsp;&nbsp;&nbsp;&nbsp;
            <button type="submit" id="submit" name="enviar">Buscar</button>
        </nav>
        <br>
        <nav>
            <a href="agregarProducto.php" class="button">Agregar Producto</a>
            &nbsp;&nbsp;&nbsp;&nbsp;
            <a href="actualizarProducto.php" class="button">Actualizar Producto</a>
            &nbsp;&nbsp;&nbsp;&nbsp;
            <a href="borrarProducto.php" class="button">Borrar Producto</a>
        </nav>
    </form>
    
    <table>
        <tr>
            <th>ID Producto</th>
            <th>Nombre</th>
            <th>Cantidad</th>
            <th>Precio</th>
        </tr>
        <?php
        if(isset($_GET['enviar'])){
            $busqueda = $_GET['busqueda'];
            $busquedaId = $_GET['busquedaId'];

            // Consulta a la tabla 'producto' con la búsqueda
            $consulta = "SELECT id_producto, nombre, cantidad, precio FROM producto WHERE nombre LIKE '%$busqueda%' AND id_producto LIKE '%$busquedaId%'";
            $resultado = mysqli_query($conexion, $consulta);

            if (mysqli_num_rows($resultado) === 0) {
                echo "<tr><td colspan='4'>No se encontraron productos.</td></tr>";
            } else {
                while ($fila = mysqli_fetch_assoc($resultado)) {
                    echo "<tr>";
                    echo "<td>" . $fila['id_producto'] . "</td>";
                    echo "<td>" . $fila['nombre'] . "</td>";
                    echo "<td>" . $fila['cantidad'] . "</td>";
                    echo "<td>" . $fila['precio'] . "</td>";
                    echo "</tr>";
                }
            }
        } else {
            // Consulta a la tabla 'producto' sin búsqueda
            $consulta = "SELECT id_producto, nombre, cantidad, precio FROM producto";
            $resultado = mysqli_query($conexion, $consulta);

            if (mysqli_num_rows($resultado) === 0) {
                echo "<tr><td colspan='4'>No se encontraron productos.</td></tr>";
            } else {
                while ($fila = mysqli_fetch_assoc($resultado)) {
                    echo "<tr>";
                    echo "<td>" . $fila['id_producto'] . "</td>";
                    echo "<td>" . $fila['nombre'] . "</td>";
                    echo "<td>" . $fila['cantidad'] . "</td>";
                    echo "<td>" . $fila['precio'] . "</td>";
                    echo "</tr>";
                }
            }
        }

        // Cerrar la conexión
        mysqli_close($conexion);
        ?>
    </table>
</body>
</html>

<?php include 'template/pie.html'; ?>
