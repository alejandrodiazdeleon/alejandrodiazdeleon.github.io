const $submit = document.getElementById("submit"),
      $password = document.getElementById("password"),
      $username = document.getElementById("username"),
      $visible = document.getElementById("visible");

document.addEventListener("change", (e)=>{
    if(e.target===$visible){
        if($visible.checked === false) $password.type = "password";
        else $password.type = "text";
    }
})

document.addEventListener("click", (e)=>{
    if(e.target === $submit){
        if($password.value !== "" && $username.value !== ""){
            e.preventDefault();
            if($username.value === "el tigre" && $password.value === "12345"){
                window.location.href = "home.php";
            }
            else window.alert("Usuario o contraseña incorrectos. Intente de nuevo")
        }
    }
})