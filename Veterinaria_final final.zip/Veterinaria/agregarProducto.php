<?php include 'template/cabezera.html'; ?>
<?php
require "conexion.php";

$conexion = abrirConexion();

// Función para insertar un nuevo producto en la base de datos
function insertarProducto($nombre, $cantidad, $precio) {
    global $conexion;

    $nombre = mysqli_real_escape_string($conexion, $nombre);
    $cantidad = mysqli_real_escape_string($conexion, $cantidad);
    $precio = mysqli_real_escape_string($conexion, $precio);

    $query = "INSERT INTO producto (nombre,cantidad, precio) VALUES ('$nombre', '$cantidad', '$precio')";
    mysqli_query($conexion, $query);
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Verificar si se hizo clic en el botón "Insertar"
    if (isset($_POST["insertar"])) {
        $nombre = $_POST["nombre"];
        $cantidad = $_POST["cantidad"];
        $precio = $_POST["precio"];

        insertarProducto($nombre, $cantidad, $precio);
    }
}
// Cerrar la conexión
mysqli_close($conexion);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Productos</title>
    <link rel="stylesheet" href="./css/styleproductos.css">
</head>
<body>
    <h1><center><font color="white">Agregar Producto</font></center></h1>
    <form method="POST" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
        <br><br>&nbsp;&nbsp;&nbsp;&nbsp;
        <input type="text" name="nombre" id="nombre" placeholder="Nombre del producto" required>
        <br>&nbsp;&nbsp;&nbsp;&nbsp;
        <input type="text" name="cantidad" id="cantidad" placeholder="Cantidad del producto" required>
        <br>&nbsp;&nbsp;&nbsp;&nbsp;
        <input type="text" name="precio" id="precio" placeholder="Precio del producto" required>
<br><br>&nbsp;&nbsp;&nbsp;&nbsp;
        <button type="submit" name="insertar">Agregar</button>
    </form>
</body>
</html>

<?php include 'template/pie.html'; ?>