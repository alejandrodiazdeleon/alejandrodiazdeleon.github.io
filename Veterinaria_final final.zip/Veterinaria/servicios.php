<?php
require "conexion.php";

$conexion = abrirConexion();

// Función para insertar un nuevo servicio en la base de datos
function insertarServicio($nombre, $descripcion, $precio) {
    global $conexion;

    $nombre = mysqli_real_escape_string($conexion, $nombre);
    $descripcion = mysqli_real_escape_string($conexion, $descripcion);
    $precio = mysqli_real_escape_string($conexion, $precio);

    $query = "INSERT INTO servicio (nombre, descripcion, precio) VALUES ('$nombre', '$descripcion', '$precio')";
    mysqli_query($conexion, $query);
}

// Función para eliminar un servicio de la base de datos
function eliminarServicio($id_servicio) {
    global $conexion;

    $id_servicio = mysqli_real_escape_string($conexion, $id_servicio);

    $query = "DELETE FROM servicio WHERE id_servicio = '$id_servicio'";
    mysqli_query($conexion, $query);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Verificar si se hizo clic en el botón "Insertar"
    if (isset($_POST["insertar"])) {
        $nombre = $_POST["nombre"];
        $descripcion = $_POST["descripcion"];
        $precio = $_POST["precio"];

        insertarServicio($nombre, $descripcion, $precio);
    }

    // Verificar si se hizo clic en el botón "Borrar"
    if (isset($_POST["borrar"])) {
        $id_servicio = $_POST["id_servicio"];

        eliminarServicio($id_servicio);
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Lista de Servicios</title>
    <style>
        body {
            background-color: #ffffff; /* Fondo blanco para toda la página */
        }

        table {
            border-collapse: collapse;
            width: 100%;
            background-color: #ffffff; /* Fondo blanco para la tabla */
        }

        table, th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: center;
        }

        th {
            background-color: #f2f2f2;
        }
        a.button {
    -webkit-appearance: button;
    -moz-appearance: button;
    appearance: button;
    outline: 0;
	background-color: #990000;
	border-radius: 20px;
	cursor: pointer;
	width: 450px;
	padding: 5px;
	transition: all .3s ease-in-out;
	text-align: center;
	color: #fff;
	font-weight: 500;
}

form button{
	outline: 0;
	background-color: #990000;
	border-radius: 20px;
	cursor: pointer;
	width: 300px;
	padding: 5px;
	transition: all .3s ease-in-out;
	text-align: center;
	color: #fff;
	font-weight: 500;
}
form button:hover{
	opacity: .75;
}
    </style>
</head>
<body>
<!DOCTYPE html>
<html lang"en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Veterinaria "El Tigre"</title>
    <link rel="stylesheet" href="./css/stylehome.css">
</head>
<body background= #FFFFFF>
    <header>
        <nav>
        <h1><img src="img/logo.png" width="90" alt="logo.png"></h1>
        <ul>
            <li><a href="home.php">HOME</a></li>
            <li><a href="productos.php">Productos</a></li>
            <li><a href="ventadeproductos.php">Venta de Productos</a></li>
            <li><a href="servicios.php">Servicios</a></li>
            <li><a href="ventaServicios.php">Venta de Servicios</a></li>
            <li><a href="agenda/index.php">Agenda</a></li>
            <li><a href="index.html">Cerrar sesion</a></li>
        </ul>
        </nav>
    </header>

    
    <table>
        <tr>
            <th>ID Servicio</th>
            <th>Nombre</th>
            <th>Descripción</th>
            <th>Precio</th>
        </tr>
        <?php
        // Consulta a la tabla 'servicio'
        $consulta = "SELECT id_servicio, nombre, descripcion, precio FROM servicio";
        $resultado = mysqli_query($conexion, $consulta);

        if (mysqli_num_rows($resultado) === 0) {
            echo "<tr><td colspan='4'>No se encontraron servicios.</td></tr>";
        } else {
            while ($fila = mysqli_fetch_assoc($resultado)) {
                echo "<tr>";
                echo "<td>" . $fila['id_servicio'] . "</td>";
                echo "<td>" . $fila['nombre'] . "</td>";
                echo "<td>" . $fila['descripcion'] . "</td>";
                echo "<td>" . $fila['precio'] . "</td>";
                echo "</tr>";
            }
        }

        // Cerrar la conexión
        mysqli_close($conexion);
        ?>
    </table>

    <h2>Insertar Servicio</h2>
    <form method="POST" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
        <label for="nombre">Nombre:</label>
        <input type="text" name="nombre" id="nombre" required>

        <label for="descripcion">Descripción:</label>
        <input type="text" name="descripcion" id="descripcion" required>

        <label for="precio">Precio:</label>
        <input type="text" name="precio" id="precio" required>

        
        <button type="submit" name="insertar">Insertar</button>
    </form>

    <h2>Borrar Servicio</h2>
    <form method="POST" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
        <label for="id_servicio">ID del Servicio a Borrar:</label>
        <input type="text" name="id_servicio" id="id_servicio" required>

        <button type="submit" name="borrar">Borrar</button>
    </form>

    <?php include 'template/pie.html'; ?>
</body>
</html>
