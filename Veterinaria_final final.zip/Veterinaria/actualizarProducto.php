<?php include 'template/cabezera.html'; ?>
<?php
require "conexion.php";

$conexion = abrirConexion();

// Función para actualizar un producto en la base de datos
function actualizarProducto($id_producto, $nombre, $cantidad, $precio) {
    global $conexion;

    $id = mysqli_real_escape_string($conexion, $id_producto);
    $nombre = mysqli_real_escape_string($conexion, $nombre);
    $cantidad = mysqli_real_escape_string($conexion, $cantidad);
    $precio = mysqli_real_escape_string($conexion, $precio);

    $query = "UPDATE producto SET nombre='$nombre', cantidad='$cantidad', precio='$precio' WHERE id_producto='$id_producto'";
    mysqli_query($conexion, $query);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Verificar si se hizo clic en el botón "Actualizar"
    if (isset($_POST["actualizar"])) {
        $id_producto = $_POST["id_producto"];
        $nombre = $_POST["nombre"];
        $cantidad = $_POST["cantidad"];
        $precio = $_POST["precio"];

        actualizarProducto($id_producto, $nombre, $cantidad, $precio);
    }
}
// Cerrar la conexión
mysqli_close($conexion);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Productos</title>
    <link rel="stylesheet" href="./css/styleproductos.css">
</head>
<body>
    <h1><center><font color="white">Actualizar Producto</font></center></h1>
    <form method="POST" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
        <br><br>&nbsp;&nbsp;&nbsp;&nbsp;
        <input type="text" name="id_producto" id="id_producto" placeholder="ID del producto a actualizar" required>
        <br>&nbsp;&nbsp;&nbsp;&nbsp;
        <input type="text" name="nombre" id="nombre" placeholder="Nombre del nuevo producto" required>
        <br>&nbsp;&nbsp;&nbsp;&nbsp;
        <input type="text" name="cantidad" id="cantidad" placeholder="Cantidad del nuevo producto" required>
        <br>&nbsp;&nbsp;&nbsp;&nbsp;
        <input type="text" name="precio" id="precio" placeholder="Precio del nuevo producto" required>
<br><br>&nbsp;&nbsp;&nbsp;&nbsp;
        <button type="submit" name="actualizar">Actualizar</button>
    </form>
</body>
</html>

<?php include 'template/pie.html'; ?>